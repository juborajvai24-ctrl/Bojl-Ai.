// Bojl AI backend
// Keep your AI API key in an environment variable, never in public/index.html.
const express = require('express');
const path = require('path');
const app = express();
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

app.post('/api/chat', async (req,res)=>{
  const message = String(req.body?.message || '').trim();
  if(!message) return res.status(400).json({reply:'প্রশ্ন লিখো।'});
  // Add your chosen AI provider SDK/API call here.
  // Example: read process.env.AI_API_KEY on the server.
  return res.json({reply:'Bojl AI backend প্রস্তুত। এখন server-এ AI provider/API সংযোগ করতে হবে।'});
});
app.listen(process.env.PORT || 3000, ()=>console.log('Bojl AI running'));
