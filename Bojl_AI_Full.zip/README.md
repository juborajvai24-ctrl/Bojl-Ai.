# Bojl AI

Bojl AI-এর মোবাইল-friendly chat website।

## গুরুত্বপূর্ণ
এই project-এ API key রাখা হয়নি। সত্যিকারের AI চালাতে hosting/server-এর environment variable-এ API key রেখে `server.js`-এর `/api/chat` অংশে AI provider-এর API call যোগ করতে হবে।

`public/index.html` হলো frontend।
`server.js` হলো backend।
